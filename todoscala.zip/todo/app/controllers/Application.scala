package controllers

import play.api.mvc._

object Application extends Controller {

  def index = Action {
    Ok(views.html.index())
  }

  def allTasks() = ???

  def deleteAllDone() = ???

  def changeTaskState(id: String) = ???

  def createTask() = ???

  def getTask(id: String) = ???

  def deleteTask(id: String) = ???

  def deleteAll() = ???
}