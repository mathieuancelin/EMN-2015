package models

import java.util.UUID

import anorm.SqlParser._
import anorm._
import play.api.Play.current
import play.api.db._
import play.api.libs.functional.syntax._
import play.api.libs.json._

case class Task(id: UUID = UUID.randomUUID(), name: String, done: Boolean)

object Task {

  implicit val taskFormat: Format[Task] = ???

  val parser: SqlParser[Task] = ???

  def findAll(): List[Task] = ???

  def findById(id: UUID): Option[Task] = ???

  def create(model: Task): Task = ???

  def delete(model: Task): Unit = ???

  def delete(id: UUID): Unit = ???

  def deleteAll(): Unit = ???

  def update(model: Task): Task = ???

  def count(): Long = ???

  def exists(model: Task): Boolean = ???
}