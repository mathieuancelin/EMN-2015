package models

import java.util.UUID

import anorm.SqlParser._
import anorm._
import play.api.Play.current
import play.api.db._
import play.api.libs.functional.syntax._
import play.api.libs.json._

case class Task(id: String = UUID.randomUUID().toString, name: String, done: Boolean)

object Task {

  implicit val taskFormat = Json.format[Task]

  val parser: RowParser[Task] = str("id") ~ str("name") ~ bool("done") map {
    case id ~ name ~ done => Task(id, name, done)
  }

  def findAll(): List[Task] = DB.withConnection { implicit connection =>
    SQL("select * from task").as(parser *)
  }

  def findById(id: String): Option[Task] = DB.withConnection { implicit connection =>
    SQL("select * from task s where s.id = {id}").on("id" -> id).as(parser.singleOpt)
  }

  def create(model: Task): Task = DB.withConnection { implicit connection =>
    SQL("insert into task values ({id}, {name}, {done})")
      .on("id" -> model.id, "name" -> model.name, "done" -> model.done).executeUpdate()
    model
  }

  def delete(model: Task): Unit = DB.withConnection { implicit connection =>
    SQL("delete from task where id = {id}").on("id" -> model.id).executeUpdate()
  }

  def delete(id: String): Unit = DB.withConnection { implicit connection =>
    SQL("delete from task where id = {id}").on("id" -> id).executeUpdate()
  }

  def deleteAll(): Unit = DB.withConnection { implicit connection =>
    SQL("delete from task").executeUpdate()
  }

  def update(model: Task): Task = DB.withConnection { implicit connection =>
    SQL("update task set name = {name}, done = {done} where id = {id}")
      .on("id" -> model.id, "name" -> model.name, "done" -> model.done).executeUpdate()
    model
  }

  def count(): Long = DB.withConnection { implicit connection =>
    val firstRow = SQL("select count(*) as c from task").apply().head
    firstRow[Long]("c")
  }

  def exists(model: Task): Boolean = findById(model.id).isDefined
}