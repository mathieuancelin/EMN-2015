package controllers

import java.util.UUID

import models.Task
import models.Task.taskFormat
import play.api.libs.json.{Json, Writes}
import play.api.mvc._

object Application extends Controller {

  def index = Action {
    Ok(views.html.index())
  }

  def allTasks() = Action {
    Ok(Json.toJson(Task.findAll())(Writes.list))
  }

  def deleteAllDone() = Action {
    Task.findAll().filter(_.done).foreach(Task.delete)
    Ok
  }

  def changeTaskState(id: String) = Action(parse.urlFormEncoded) { r =>
    //val opt = for {
    //  task <- Task.findById(id)
    //  done <- r.body.getOrElse("done", Seq()).headOption
    //} yield Task.update(task.copy(done = done.toBoolean))

    val opt = Task.findById(id).flatMap { task =>
      r.body.getOrElse("done", Seq()).headOption.map { done =>
        Task.update(task.copy(done = done.toBoolean))
      }
    }
    opt.map(t => Ok(Json.toJson(t))).getOrElse(NotFound)
  }

  def createTask() = Action(parse.urlFormEncoded) { r =>
    r.body.getOrElse("name", Seq()).headOption match {
      case Some(name) => Ok(Json.toJson(Task.create(Task(name = name, done = false))))
      case None => BadRequest("Name was no specified")
    }
  }

  def getTask(id: String) = Action {
    Task.findById(id).map(t => Ok(Json.toJson(t))).getOrElse(NotFound)
  }

  def deleteTask(id: String) = Action {
    Task.delete(id)
    Ok
  }

  def deleteAll() = Action {
    Task.deleteAll()
    Ok
  }
}