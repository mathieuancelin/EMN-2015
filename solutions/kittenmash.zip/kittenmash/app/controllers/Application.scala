package controllers

import java.util.UUID
import play.api.mvc._
import models._

object Application extends Controller {

  def index = Action {
    val cats = Cat.randomCats()
    Ok(views.html.index(cats.head, cats.tail.head))
  }

  def stats = Action {
    Ok(views.html.stats(Cat.findAll().sortWith({ (cat1, cat2) => cat1.picked.compareTo(cat2.picked) > 0})))
  }

  def pickACat(id: String, id2: String, panelId: Long) = Action {
    Cat.findById(UUID.fromString(id)).toRight(BadRequest("Unkown kitten with id " + id)).fold(identity, { c =>
      c.pick()
      val random = Cat.randomCats().filter(cat => cat.id != c.id && id2 != c.id.toString).head
      panelId match {
        case 1 => Ok(views.html.index(c, random))
        case _ => Ok(views.html.index(random, c))
      }
    })
  }
}