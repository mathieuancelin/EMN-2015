package models

import anorm._
import play.api.db._
import anorm.SqlParser._
import play.api.Play.current
import java.util.{UUID, Random}

case class Cat(id: UUID = UUID.randomUUID(), url: String, picked: Long) {
  def save(): Cat = Cat.save(this)
  def pick() = Cat.update(this.copy(picked = picked + 1 ))
}

object Cat {

  val simple = {
    get[UUID]("cat.id") ~ get[String]("cat.url") ~ get[Long]("cat.picked") map {
      case id ~ url ~ picked => Cat(id, url, picked)
    }
  }

  def randomCats(): List[Cat] = DB.withConnection { implicit connection =>
    SQL("select * from cat order by Rand()").as(Cat.simple *)
  }

  def findAll(): List[Cat] = DB.withConnection { implicit connection =>
    SQL("select * from cat order by id asc").as(Cat.simple *)
  }

  def findById(id: UUID): Option[Cat] = DB.withConnection { implicit connection =>
    SQL("select * from cat s where s.id = {id}").on("id" -> id).as(Cat.simple.singleOpt)
  }

  def create(cat: Cat): Cat = DB.withConnection { implicit connection =>
    SQL("insert into cat values ( {id}, {url}, {picked} )").on("id" -> cat.id, "url" -> cat.url, "picked" -> 0).executeUpdate()
    cat
  }

  def save(cat: Cat): Cat = {
    if (Cat.findById(cat.id).isDefined) {
      Cat.update(cat)
    } else {
      Cat.create(cat)
    }
  }

  def delete(id: UUID): Unit = DB.withConnection { implicit connection =>
    SQL("delete from cat where id = {id}").on("id" -> id).executeUpdate()
  }

  def deleteAll(): Unit = DB.withConnection { implicit connection =>
    SQL("delete from cat").executeUpdate()
  }

  def update(cat: Cat): Cat = DB.withConnection { implicit connection =>
    SQL("update cat set url = {url}, picked = {picked} where id = {id}").on("id" -> cat.id, "url" -> cat.url, "picked" -> cat.picked).executeUpdate()
    cat
  }

  def count(): Long = DB.withConnection { implicit connection =>
    val firstRow = SQL("select count(*) as s from cat").apply().head
    firstRow[Long]("s")
  }

  def exists(cat: Cat) = Cat.findById(cat.id).isDefined
}