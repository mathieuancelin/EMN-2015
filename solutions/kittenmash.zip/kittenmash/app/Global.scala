import models._
import play.api._

object Global extends GlobalSettings {

  val IMG_FILE = "public/img"
  val IMG_URL = "/assets/img/"

  override def onStart(app: Application) {
    Cat.deleteAll()
    app.getFile(IMG_FILE).listFiles().foreach { img =>
      Cat(url = IMG_URL + img.getName(), picked = 0).save()
    }
  }
}