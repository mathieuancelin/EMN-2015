# --- !Ups

create table cat (
  id                        varchar(255),
  url                       varchar(255),
  picked                    bigint not null,
  constraint pk_cat primary key (id)
);

# --- !Downs
