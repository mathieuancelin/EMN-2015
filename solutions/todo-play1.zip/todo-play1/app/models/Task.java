package models;

import play.db.jpa.Model;

import javax.persistence.Entity;

@Entity
public class Task extends Model {

    public String name;
    public Boolean done;

    public Task(String name) {
        this.name = name;
        this.done = false;
    }
}
