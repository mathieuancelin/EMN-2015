package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

public class Application extends Controller {

    public static void index() {
        render();
    }

    public static void allTasks() {
        renderJSON(Task.findAll());
    }

    public static void createTask(String name) {
        renderJSON(new Task(name).save());
    }

    public static void deleteAll() {
        Task.deleteAll();
        ok();
    }

    public static void deleteAllDone() {
        List<Task> tasks = Task.findAll();
        for(Task task : tasks) {
            if (task.done) {
                task.delete();
            }
        }
        ok();
    }

    public static void getTask(Long id) {
        renderJSON(Task.findById(id));
    }

    public static void changeTaskState(Long id, Boolean done) {
        Task task = Task.findById(id);
        task.done = done;
        renderJSON(task.save());
    }

    public static void deleteTask(Long id) {
        Task.findById(id)._delete();
        ok();
    }

}