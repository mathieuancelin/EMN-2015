var Student = Student || {};
(function(exports) {
    function displayUI() {
        function item(name) {
            return '<li class="list-group-item">                                              ' +
                '<div class="row">                                                         ' +
                    '<div class="col-md-10">' + name + '</div>                                        ' +
                    '<div class="col-md-2">                                                    ' +
                        '<span class="label label-success" style="cursor: pointer;">Done</span>    ' +
                    '</div>                                                                    ' +
                '</div>                                                                    ' +
            '</li>';
        }

        $('#save').click(function(e) {
            e.preventDefault();
            var name = $('#name').val();
            $.post('/api/task', { name: name }, function(data) {
                $('#tasks').append(item(name));
            });
        });
    }
    exports.displayUI = displayUI;
})(Student);