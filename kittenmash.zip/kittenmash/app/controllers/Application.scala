package controllers

import play.api.mvc._
import models._

object Application extends Controller {

  def index = Action {
    Ok(views.html.index())
  }

  def stats = Action {
    Ok(views.html.stats())
  }
}