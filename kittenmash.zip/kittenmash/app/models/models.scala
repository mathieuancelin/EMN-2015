package models

import anorm._
import play.api.db._
import anorm.SqlParser._
import play.api.Play.current
import java.util.{UUID, Random}

case class Cat(id: UUID = UUID.randomUUID(), url: String, picked: Long) 

object Cat {

  val simple: SqlParser[Cat] = ???

  def randomCats(): List[Cat] = ???

  def findAll(): List[Cat] = ???

  def findById(id: UUID): Option[Cat] = ???

  def create(cat: Cat): Cat = ???

  def deleteAll(): Unit = ???

  def update(cat: Cat): Cat = ???
}